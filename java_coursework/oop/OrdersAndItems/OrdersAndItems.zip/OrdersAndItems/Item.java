import java.util.ArrayList;
public class Item{
    public String name;
    public double price;
}