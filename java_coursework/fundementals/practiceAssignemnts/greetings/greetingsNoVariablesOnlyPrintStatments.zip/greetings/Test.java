public class Test{
        public static void main(String[]args){      
            System.out.println("My name is Matthew Baiamonte");
            System.out.println("I am 26 years old");
            System.out.println("My hometown in Dover-Foxcroft Maine");
            System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");


        }
}