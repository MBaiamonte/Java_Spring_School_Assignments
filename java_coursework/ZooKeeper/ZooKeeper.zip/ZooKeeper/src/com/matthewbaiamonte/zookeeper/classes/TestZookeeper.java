package com.matthewbaiamonte.zookeeper.classes;

public class TestZookeeper {

	public static void main(String[] args) {
		
		//<<<<Gorilla tests>>>>
//		Gorilla toby = new Gorilla();
//		toby.displayEnergy();
//		toby.throwObject(3);
//		toby.eatBanana(2);
//		toby.climb();
		
		//<<<<<MeglaBat tests>>>>>
		MeglaBat lizzy =new MeglaBat();
		lizzy.displayEnergy();
		lizzy.fly(2);
		lizzy.eatHumans(2);
		lizzy.attackTown(3);
		
		

		
		
		
		
	}//end main
}//end class
